<?php 

class Pencarian extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('m_pencarian');
	}

	function pencarianGenre(){
		$genre=$this->input->post('genre');
		$data['acara'] = $this->m_pencarian->tampilGenre($genre)->result();
		$this->load->view('v_pencarian', $data);
	}

	function pencarianLokasi(){
		$lokasi=$this->input->post('lokasi');
		$data['acara'] = $this->m_pencarian->tampilLokasi($lokasi)->result();
		$this->load->view('v_pencarian', $data);
	}

	function limateratas(){
		$data['acara'] = $this->m_pencarian->tampilLimaTeratas()->result();
		$this->load->view('v_pencarian', $data);
	}
}

 ?>